# 智能家居设备权限管理系统

本项目包含了智能家居设备权限管理系统的设计原型和组件库。

## 项目结构

```
smart-home-system/
├── design-system/        # 组件库
│   ├── src/
│   │   ├── components/   # React 组件
│   │   └── stories/     # Storybook 故事
│   └── package.json     # 依赖配置
├── prototype/           # 交互原型
│   └── index.html      # 可运行的HTML原型
└── README.md           # 项目说明文档
```

## 功能模块

### 1. 多角色看板设计

#### 1.1 角色划分
- 家庭管理员(Admin)：权限最高，拥有设备的全面控制权限和用户管理权限
- 普通用户(User)：拥有设备的基本控制权限，能查看自己权限范围内的设备状态
- 访客(Guest)：权限最小，只能控制特定设备且有时间限制

#### 1.2 看板界面差异化
- AdminPanel：设备开关 + 固件升级 + 能耗统计
- UserPanel：设备开关 + 基本操作
- GuestPanel：仅设备开关 + 倒计时显示

### 2. 界面设计风格
- 简洁现代的设计风格
- 蓝绿色系主色调
- 响应式设计，支持PC和移动端
- 卡片式布局

### 3. 无障碍设计
- 支持键盘导航
- ARIA标签支持
- 高对比度模式
- 字号可调整

## 运行说明

### 查看交互原型
1. 打开 `prototype/index.html` 文件
2. 可以在浏览器中直接查看和交互

### 运行组件库（需要Node.js环境）
1. 进入 design-system 目录
2. 安装依赖：`npm install`
3. 启动 Storybook：`npm run storybook`

## 设计规范

### 颜色系统
- 主色：#2196f3（蓝色）
- 次色：#00bcd4（青色）
- 警告色：#f44336（红色）
- 背景色：#ffffff（白色）
- 文字色：#333333（深灰）

### 字体系统
- 主要字体：-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto
- 标题大小：24px/20px/16px
- 正文大小：14px
- 辅助文字：12px

### 间距系统
- 基础间距：8px
- 组件间距：16px/24px
- 区块间距：32px

## 注意事项
1. 原型仅作演示用途，不包含实际功能
2. 组件库需要 Node.js 环境支持
3. 设计规范需要在实际开发中严格遵守 