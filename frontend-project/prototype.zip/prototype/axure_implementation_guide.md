# Axure 智能家居系统实现指南

## 1. 页面结构

### 1.1 登录页面 (login)
```
页面名称: login
尺寸: 1920 x 1080px
背景色: #ffffff

组件:
1. 登录框 (loginPanel)
   - 类型: Dynamic Panel
   - 位置: 居中
   - 尺寸: 400 x 500px
   - 背景色: #ffffff
   - 阴影: 0 2px 10px rgba(0,0,0,0.1)

2. 输入字段
   - 用户名输入框 (txtUsername)
     位置: {x: 50, y: 150}
     尺寸: 300 x 40px
     占位文本: "请输入用户名"
   
   - 密码输入框 (txtPassword)
     位置: {x: 50, y: 220}
     尺寸: 300 x 40px
     占位文本: "请输入密码"
     类型: password

3. 角色选择 (roleSelector)
   - 类型: Dropdown
   - 位置: {x: 50, y: 290}
   - 选项:
     * 管理员 (ADMIN)
     * 普通用户 (USER)
     * 访客 (GUEST)

4. 登录按钮 (btnLogin)
   - 位置: {x: 50, y: 360}
   - 尺寸: 300 x 45px
   - 背景色: #2196f3
   - 文字颜色: #ffffff
```

### 1.2 管理员面板 (admin_dashboard)
```
页面名称: admin_dashboard
布局: 网格布局

组件:
1. 顶部导航栏 (navBar)
   - 位置: {x: 0, y: 0}
   - 尺寸: 1920 x 60px
   - 背景色: #2196f3
   
2. 设备控制面板 (devicePanel)
   - 类型: Repeater
   - 布局: 网格 (3列)
   - 设备类型:
     * 灯控制器
     * 空调控制器
     * 窗帘控制器
     * 洗衣机控制器
     * 扫地机器人控制器

3. 用户管理面板 (userManagementPanel)
   - 位置: 右侧
   - 尺寸: 300px 宽

4. 能耗统计面板 (energyStatsPanel)
   - 位置: 底部
   - 类型: 图表面板
```

### 1.3 用户面板 (user_dashboard)
```
页面名称: user_dashboard
布局: 类似admin_dashboard，但移除管理功能

组件:
1. 设备控制卡片 (deviceCard)
   - 尺寸: 300 x 200px
   - 内容:
     * 设备图标
     * 设备名称
     * 开关按钮
     * 状态显示
```

### 1.4 访客面板 (guest_dashboard)
```
页面名称: guest_dashboard
布局: 简化版user_dashboard

组件:
1. 倒计时显示 (timerDisplay)
   - 位置: 顶部
   - 显示剩余访问时间
```

## 2. 交互定义

### 2.1 登录流程
```javascript
// 登录按钮点击事件
OnClick(btnLogin) {
    // 获取输入值
    var username = GetValue(txtUsername);
    var password = GetValue(txtPassword);
    var role = GetValue(roleSelector);
    
    // 角色判断
    switch(role) {
        case "ADMIN":
            OpenPage(admin_dashboard);
            break;
        case "USER":
            OpenPage(user_dashboard);
            break;
        case "GUEST":
            OpenPage(guest_dashboard);
            break;
    }
}
```

### 2.2 设备控制
```javascript
// 设备开关切换
OnClick(deviceSwitch) {
    // 获取设备状态
    var currentStatus = GetWidgetState(deviceSwitch);
    
    // 切换状态
    if(currentStatus == "off") {
        SetWidgetState(deviceSwitch, "on");
        SetDeviceStatus(deviceId, "on");
    } else {
        SetWidgetState(deviceSwitch, "off");
        SetDeviceStatus(deviceId, "off");
    }
}
```

### 2.3 权限控制
```javascript
// 权限检查函数
function CheckPermission(userId, deviceId) {
    // 获取用户角色
    var userRole = GetUserRole(userId);
    
    // 权限判断
    switch(userRole) {
        case "ADMIN":
            return true;
        case "USER":
            return GetUserDevicePermission(userId, deviceId);
        case "GUEST":
            return CheckGuestTimeValidity(userId) && 
                   GetGuestDevicePermission(userId, deviceId);
    }
}
```

## 3. 数据接口定义

### 3.1 用户接口
```javascript
interface User {
    id: string;
    username: string;
    role: "ADMIN" | "USER" | "GUEST";
    permissions: DevicePermission[];
}

interface DevicePermission {
    deviceId: string;
    canControl: boolean;
    canViewStats: boolean;
    startTime?: Date;  // 访客权限开始时间
    endTime?: Date;    // 访客权限结束时间
}
```

### 3.2 设备接口
```javascript
interface Device {
    id: string;
    name: string;
    type: "LIGHT" | "AC" | "CURTAIN" | "WASHING_MACHINE" | "ROBOT";
    status: "on" | "off";
    energyConsumption: number;
}
```

## 4. 样式指南

### 4.1 颜色系统
```css
:root {
    --primary: #2196f3;
    --secondary: #00bcd4;
    --warning: #f44336;
    --background: #ffffff;
    --text: #333333;
}
```

### 4.2 字体系统
```css
:root {
    --font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto;
    --font-size-title: 24px;
    --font-size-body: 14px;
    --font-size-small: 12px;
}
```

## 5. 实现步骤

1. 创建页面框架
   - 创建所有必要的页面
   - 设置页面尺寸和背景色

2. 构建母版页面
   - 创建导航栏母版
   - 创建设备卡片母版
   - 创建页脚母版

3. 实现登录页面
   - 添加所有登录组件
   - 设置登录交互

4. 实现仪表板
   - 创建设备控制面板
   - 添加用户管理功能（管理员）
   - 添加能耗统计图表

5. 实现设备控制
   - 创建设备卡片组件
   - 添加设备控制交互
   - 实现状态反馈

6. 添加权限控制
   - 实现角色判断
   - 添加访问限制
   - 设置时间控制（访客）

7. 优化交互体验
   - 添加加载状态
   - 实现错误提示
   - 添加操作反馈

## 6. 测试用例

### 6.1 登录测试
```
测试用例1: 管理员登录
输入:
- 用户名: admin
- 密码: admin123
- 角色: ADMIN
预期结果: 跳转到管理员面板

测试用例2: 访客登录
输入:
- 用户名: guest
- 密码: guest123
- 角色: GUEST
预期结果: 跳转到访客面板，显示倒计时
```

### 6.2 设备控制测试
```
测试用例1: 设备开关
操作: 点击设备开关按钮
预期结果: 设备状态切换，UI更新

测试用例2: 权限控制
操作: 访客尝试控制未授权设备
预期结果: 显示权限不足提示
```

## 7. 注意事项

1. 所有交互都需要添加适当的状态反馈
2. 确保所有输入都有合适的验证
3. 添加适当的加载状态显示
4. 实现错误处理和提示
5. 确保所有页面都是响应式的
6. 添加适当的动画过渡效果
7. 实现数据持久化存储
8. 添加会话超时处理 