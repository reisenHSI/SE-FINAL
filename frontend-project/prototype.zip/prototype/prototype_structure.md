# Smart Home System Prototype Structure

## Models (Suggested Data Structure)

```python
# models.py
from django.db import models
from django.contrib.auth.models import User

class Device(models.Model):
    name = str
    type = str  # ['LIGHT', 'AC', 'CURTAIN', 'WASHING_MACHINE', 'ROBOT']
    status = bool
    firmware_version = str
    energy_consumption = float

class Permission(models.Model):
    user = User
    device = Device
    role = str  # ['ADMIN', 'USER', 'GUEST']
    start_time = datetime
    end_time = datetime
    can_control = bool
    can_view_stats = bool
    can_update_firmware = bool
```

## Views (Interface Definitions)

```python
# views.py
class DeviceViewSet:
    def list_devices(user_id):
        """GET /api/devices/
        Returns devices based on user role and permissions
        """
        pass

    def control_device(user_id, device_id, action):
        """POST /api/devices/{device_id}/control
        Controls device if user has permission
        """
        pass

    def update_firmware(user_id, device_id, firmware):
        """POST /api/devices/{device_id}/update
        Admin only - updates device firmware
        """
        pass

class StatsViewSet:
    def get_energy_stats(user_id, device_id):
        """GET /api/stats/energy/{device_id}
        Returns energy consumption statistics
        """
        pass

class UserManagementViewSet:
    def manage_permissions(admin_id, user_id, permissions):
        """POST /api/users/{user_id}/permissions
        Admin only - manages user permissions
        """
        pass
```

## Axure Prototype Pages

1. Login Page (`login.rp`)
   - Login form
   - Role selection
   - Remember me
   - Forgot password

2. Admin Dashboard (`admin_dashboard.rp`)
   - Device overview cards
   - User management panel
   - Energy statistics
   - Firmware update interface
   
3. User Dashboard (`user_dashboard.rp`)
   - Device control cards
   - Basic device statistics
   - Personal settings

4. Guest Dashboard (`guest_dashboard.rp`)
   - Limited device controls
   - Timer countdown
   - Access period display

## Component Library

1. Device Cards
   - Light control (灯.png)
   - AC control (空调.png)
   - Curtain control (窗帘.png)
   - Washing machine control (洗衣机.png)
   - Robot vacuum control (扫地机器人.png)

2. Common Components
   - Navigation bar
   - User profile menu
   - Notification center
   - Settings panel

## Color Scheme
- Primary: #2196f3
- Secondary: #00bcd4
- Warning: #f44336
- Background: #ffffff
- Text: #333333

## Typography
- Headers: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto
- Body: 14px
- Small text: 12px

## Interaction Patterns

1. Device Control
   ```javascript
   async function controlDevice(deviceId, action) {
     const response = await fetch(`/api/devices/${deviceId}/control`, {
       method: 'POST',
       body: JSON.stringify({ action })
     });
     return response.json();
   }
   ```

2. Permission Check
   ```javascript
   async function checkPermission(userId, deviceId) {
     const response = await fetch(`/api/users/${userId}/permissions/${deviceId}`);
     return response.json();
   }
   ```

3. Stats Update
   ```javascript
   async function updateStats(deviceId) {
     const response = await fetch(`/api/stats/energy/${deviceId}`);
     return response.json();
   }
   ```

## Navigation Flow
```mermaid
graph TD
    Login --> |Admin| AdminDashboard
    Login --> |User| UserDashboard
    Login --> |Guest| GuestDashboard
    AdminDashboard --> DeviceControl
    AdminDashboard --> UserManagement
    AdminDashboard --> EnergyStats
    UserDashboard --> DeviceControl
    UserDashboard --> BasicStats
    GuestDashboard --> LimitedControl
```

## Accessibility Features
- ARIA labels implementation
- Keyboard navigation support
- High contrast mode
- Adjustable font sizes

## Notes for Axure Implementation
1. Use master pages for common layouts
2. Create a shared widget library for device controls
3. Implement role-based conditional visibility
4. Add interactive prototyping for all device controls
5. Include error states and loading indicators 